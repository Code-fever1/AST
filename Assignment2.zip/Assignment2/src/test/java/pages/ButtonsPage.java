package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ButtonsPage {
    WebDriver driver;
    Actions actions;

    @FindBy(id = "doubleClickBtn")
    WebElement doubleClickBtn;

    @FindBy(id = "rightClickBtn")
    WebElement rightClickBtn;

    @FindBy(id = "doubleClickMessage")
    WebElement doubleClickMessage;

    @FindBy(id = "rightClickMessage")
    WebElement rightClickMessage;

    public ButtonsPage(WebDriver driver) {
        this.driver = driver;
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    public String doubleClick() {
        actions.doubleClick(doubleClickBtn).perform();
        return doubleClickMessage.getText();
    }

    public String rightClick() {
        actions.contextClick(rightClickBtn).perform();
        return rightClickMessage.getText();
    }
}
