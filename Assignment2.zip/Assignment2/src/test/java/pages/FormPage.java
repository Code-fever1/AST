package pages;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FormPage {
    WebDriver driver;
    Actions actions;

    @FindBy(name = "username")
    WebElement username;

    @FindBy(name = "comments")
    WebElement textArea;

    @FindBy(css = "input[type='submit']")
    WebElement submitBtn;

    public FormPage(WebDriver driver) {
        this.driver = driver;
        actions = new Actions(driver);
        PageFactory.initElements(driver, this);
    }

    public void fillForm(String regNo, String dob, String address) {
        // bring the form into view first so the click lands on Username
        actions.scrollToElement(textArea).perform();
        textArea.clear();
        actions.sendKeys(username, regNo)
                .sendKeys(Keys.TAB)
                .sendKeys(dob)
                .sendKeys(Keys.TAB)
                .sendKeys(address)
                .build()
                .perform();
    }

    public void scrollToBottom() {
        // leave the text area, otherwise END only moves the cursor inside it
        actions.sendKeys(Keys.TAB).perform();
        actions.sendKeys(Keys.CONTROL, Keys.END).perform();
    }

    public void scrollToSubmit() {
        actions.scrollToElement(submitBtn).perform();
    }
}
