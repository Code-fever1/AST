package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoadingPage {
    WebDriver driver;

    @FindBy(xpath = "//button[text()='Start']")
    WebElement startBtn;

    public LoadingPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickStart() {
        startBtn.click();
    }
}
