package tests;

import base.BaseTest;
import config.ConfigReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import pages.ButtonsPage;
import pages.FormPage;
import pages.LoadingPage;

import java.time.Duration;

public class AssignmentTest extends BaseTest {

    @Test
    public void testAssignment() throws InterruptedException {
        String fullName = ConfigReader.getProperty("fullName");
        String regNo = ConfigReader.getProperty("regNo");
        String dob = ConfigReader.getProperty("dateOfBirth");
        String address = ConfigReader.getProperty("homeAddress");
        String section = ConfigReader.getProperty("section");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(25));

        // Task 1
        driver.get(ConfigReader.getProperty("buttonsUrl"));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("header img")));
        ButtonsPage buttonsPage = new ButtonsPage(driver);
        System.out.println("Double click message: " + buttonsPage.doubleClick());
        System.out.println("Right click message: " + buttonsPage.rightClick());
        Thread.sleep(2000);
        String demoqaWindow = driver.getWindowHandle();

        // Task 2
        driver.switchTo().newWindow(WindowType.TAB);
        driver.get(ConfigReader.getProperty("formUrl"));
        String formWindow = driver.getWindowHandle();

        FormPage formPage = new FormPage(driver);
        formPage.fillForm(regNo, dob, address);
        Thread.sleep(1000);
        formPage.scrollToBottom();
        Thread.sleep(1200);
        formPage.scrollToSubmit();
        Thread.sleep(2000);

        driver.switchTo().window(demoqaWindow);
        System.out.println("Demoqa title: " + driver.getTitle());
        driver.close();

        // Task 3
        driver.switchTo().window(formWindow);
        driver.switchTo().newWindow(WindowType.WINDOW);
        driver.get(ConfigReader.getProperty("loadingUrl"));
        String loadingWindow = driver.getWindowHandle();

        LoadingPage loadingPage = new LoadingPage(driver);
        loadingPage.clickStart();

        WebElement message = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("finish")));
        System.out.println("Displayed text: " + message.getText());
        Thread.sleep(2500);
        driver.close();

        driver.switchTo().window(formWindow);
        System.out.println("Test pages title: " + driver.getTitle());
        System.out.println("Name: " + fullName);
        System.out.println("Registration Number: " + regNo);
        System.out.println("Section: " + section);
    }
}
